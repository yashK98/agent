"""Setup for AIDS Agent."""

from setuptools import setup, find_packages

setup(
    name="aids-agent",
    version="0.1.0",
    description="AI-powered FastAPI project automation",
    author="Your Organization",
    packages=find_packages(),
    install_requires=[
        "click>=8.0.0",
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "gitpython>=3.1.0",
    ],
    entry_points={
        "console_scripts": [
            "aids-agent=aids_agent.cli:main",
        ],
    },
    python_requires=">=3.8",
)
