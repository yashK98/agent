# AIDS Agent

AI-powered assistant for creating FastAPI projects and deploying to Azure DevOps.

## Quick Start

### 1. Install

```bash
pip install -e .
```

### 2. Configure

```bash
aids-agent configure
```

Enter your credentials:
- **Databricks endpoint**: Your workspace URL + `/mlflow/v1/chat/completions`
- **Databricks token**: Your hourly auth token
- **Model**: `databricks-claude-sonnet-4-6` (recommended)
- **ADO PAT token**: Your Azure DevOps Personal Access Token
- **Organization**: Your ADO org name

### 3. Use It

**Interactive mode:**
```bash
aids-agent chat
```

**Quick command:**
```bash
aids-agent create my-api --repo https://dev.azure.com/org/proj/_git/my-api --branch main
```

**Test setup:**
```bash
aids-agent test
```

## What It Does

- ✅ Creates FastAPI projects using your `aids-cli` utility
- ✅ Checks if ADO repositories exist
- ✅ Creates git branches automatically
- ✅ Pushes code directly to Azure DevOps
- ✅ Lists project files

## Example Conversation

```
You: Create a FastAPI project called user-service

Agent: I'll create a FastAPI project called 'user-service'.
       Would you like me to push this to a repository?

You: Yes, push to https://dev.azure.com/myorg/proj/_git/user-service

Agent: What branch should I use?

You: develop

Agent: ✓ Project created
       ✓ Branch 'develop' created
       ✓ Code pushed successfully
```

## Configuration File

Located at: `~/.aids-agent/config.yaml`

```yaml
databricks:
  endpoint: "https://..."
  token: "your-token"
  model: "databricks-claude-sonnet-4-6"
  max_tokens: 4096

ado:
  pat_token: "your-pat"
  organization: "your-org"
  git_user_name: "AIDS Agent"
  git_user_email: "aids-agent@company.com"
```

## Requirements

- Python 3.8+
- `aids-cli` installed (`pip install aids-cli`)
- Databricks access with Claude models
- Azure DevOps account with PAT token

## Troubleshooting

**"aids-cli not found"**
```bash
pip install aids-cli
```

**"Databricks connection failed"**
- Token expired? Regenerate and run `aids-agent configure`

**"Repository access failed"**
- Check PAT token has Code (Read & Write) permissions

## Commands

- `aids-agent configure` - Set up credentials
- `aids-agent chat` - Interactive mode
- `aids-agent create <name>` - Quick create project
- `aids-agent test` - Test configuration

## License

MIT
