"""Command-line interface for AIDS Agent."""

import click
from aids_agent.config import load_config, save_config, get_default_config
from aids_agent.agent import Agent


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """AIDS Agent - AI-powered FastAPI project automation."""
    pass


@cli.command()
def configure():
    """Configure AIDS Agent."""
    print("\n=== AIDS Agent Configuration ===\n")
    
    print("Databricks Configuration:")
    endpoint = input("Endpoint URL: ").strip()
    token = input("Auth Token: ").strip()
    model = input("Model [databricks-claude-sonnet-4-6]: ").strip() or "databricks-claude-sonnet-4-6"
    
    print("\nAzure DevOps Configuration:")
    pat = input("PAT Token: ").strip()
    org = input("Organization: ").strip()
    
    print("\nGit Configuration:")
    name = input("Git User Name [AIDS Agent]: ").strip() or "AIDS Agent"
    email = input("Git User Email [aids-agent@company.com]: ").strip() or "aids-agent@company.com"
    
    config = {
        "databricks": {
            "endpoint": endpoint,
            "token": token,
            "model": model,
            "max_tokens": 4096
        },
        "ado": {
            "pat_token": pat,
            "organization": org,
            "git_user_name": name,
            "git_user_email": email
        }
    }
    
    try:
        save_config(config)
        print(f"\n✓ Configuration saved!\n")
    except Exception as e:
        print(f"\n✗ Error: {e}\n")


@cli.command()
def chat():
    """Start interactive chat session."""
    print("\n🤖 AIDS Agent - Interactive Mode")
    print("Type 'exit' or 'quit' to end session\n")
    
    try:
        config = load_config()
        agent = Agent(config)
    except Exception as e:
        print(f"✗ Error: {e}\n")
        return
    
    while True:
        try:
            user_input = input("\nYou: ").strip()
            
            if user_input.lower() in ['exit', 'quit', 'bye']:
                print("\nGoodbye! 👋\n")
                break
            
            if not user_input:
                continue
            
            print("\n🤖 Agent: ", end="", flush=True)
            response = agent.chat(user_input)
            print(response)
            
        except KeyboardInterrupt:
            print("\n\nGoodbye! 👋\n")
            break
        except Exception as e:
            print(f"\n✗ Error: {e}")


@cli.command()
@click.argument('project_name')
@click.option('--repo', help='Repository URL to push to')
@click.option('--branch', default='main', help='Branch name')
@click.option('--no-push', is_flag=True, help="Don't push to repository")
def create(project_name, repo, branch, no_push):
    """Quick create FastAPI project."""
    try:
        config = load_config()
        agent = Agent(config)
    except Exception as e:
        print(f"✗ Error: {e}\n")
        return
    
    # Build message
    if repo and not no_push:
        msg = f"Create a FastAPI project '{project_name}' and push to {repo} branch {branch}"
    else:
        msg = f"Create a FastAPI project '{project_name}'"
    
    print(f"\n🤖 {msg}...\n")
    response = agent.chat(msg)
    print(response)
    print()


@cli.command()
def test():
    """Test configuration."""
    print("\n=== Testing Configuration ===\n")
    
    try:
        config = load_config()
        print("✓ Configuration loaded")
        
        # Test Databricks connection
        print("\nTesting Databricks connection...")
        from aids_agent.databricks import DatabricksClient
        
        client = DatabricksClient(
            endpoint=config["databricks"]["endpoint"],
            token=config["databricks"]["token"],
            model=config["databricks"]["model"]
        )
        
        # Simple test call
        response = client.chat([{"role": "user", "content": "Hi"}])
        if response.get("choices"):
            print("✓ Databricks connection successful")
        else:
            print("✗ Databricks connection failed")
        
        # Test aids-cli
        print("\nChecking aids-cli...")
        from aids_agent.tools import AIDSCLIWrapper
        try:
            aids = AIDSCLIWrapper()
            print("✓ aids-cli found")
        except FileNotFoundError as e:
            print(f"✗ {e}")
        
        print("\n✓ Configuration test complete!\n")
        
    except Exception as e:
        print(f"✗ Error: {e}\n")


def main():
    """Entry point."""
    cli()


if __name__ == "__main__":
    main()
