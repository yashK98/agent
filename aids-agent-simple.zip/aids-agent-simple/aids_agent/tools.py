"""All agent tools in one file."""

import subprocess
import shutil
import tempfile
from pathlib import Path
from urllib.parse import urlparse, urlunparse
import git


class AIDSCLIWrapper:
    """Wrapper for aids-cli utility."""
    
    def __init__(self):
        self.executable = shutil.which("aids")
        if not self.executable:
            raise FileNotFoundError("aids-cli not found. Install with: pip install aids-cli")
    
    def create_project(self, project_name, directory=None):
        """Create a new FastAPI project."""
        cmd = [self.executable, "init", "python", project_name]
        cwd = directory or "."
        
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=120
            )
            return result.returncode == 0, result.stdout, result.stderr
        except Exception as e:
            return False, "", str(e)
    
    def get_project_path(self, project_name, directory=None):
        """Get path where project would be created."""
        base_dir = Path(directory) if directory else Path.cwd()
        return base_dir / project_name


class GitManager:
    """Azure DevOps git operations."""
    
    def __init__(self, pat_token, organization, git_user_name, git_user_email):
        self.pat_token = pat_token
        self.organization = organization
        self.git_user_name = git_user_name
        self.git_user_email = git_user_email
    
    def _get_authenticated_url(self, repo_url):
        """Add PAT token to URL for authentication."""
        parsed = urlparse(repo_url)
        netloc = f"{self.pat_token}@{parsed.netloc}"
        return urlunparse((
            parsed.scheme, netloc, parsed.path,
            parsed.params, parsed.query, parsed.fragment
        ))
    
    def check_repository_exists(self, repo_url):
        """Check if repository exists."""
        try:
            auth_url = self._get_authenticated_url(repo_url)
            result = subprocess.run(
                ["git", "ls-remote", auth_url],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return True, "Repository exists and is accessible"
            else:
                return False, "Repository not found or access denied"
        except Exception as e:
            return False, str(e)
    
    def check_branch_exists(self, repo_url, branch_name):
        """Check if a branch exists."""
        try:
            auth_url = self._get_authenticated_url(repo_url)
            result = subprocess.run(
                ["git", "ls-remote", "--heads", auth_url],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                branch_ref = f"refs/heads/{branch_name}"
                if branch_ref in result.stdout:
                    return True, f"Branch '{branch_name}' exists"
                return False, f"Branch '{branch_name}' not found"
            return False, "Error checking branches"
        except Exception as e:
            return False, str(e)
    
    def create_branch(self, repo_url, branch_name, source_branch="main"):
        """Create a new branch."""
        temp_dir = None
        try:
            auth_url = self._get_authenticated_url(repo_url)
            temp_dir = tempfile.mkdtemp(prefix="aids-agent-")
            
            # Clone repository
            subprocess.run(
                ["git", "clone", "--depth", "1", "--branch", source_branch, auth_url, temp_dir],
                capture_output=True,
                timeout=120,
                check=True
            )
            
            # Create and push new branch
            repo = git.Repo(temp_dir)
            repo.git.checkout("-b", branch_name)
            repo.git.push("origin", branch_name)
            
            return True, f"Branch '{branch_name}' created from '{source_branch}'"
        except Exception as e:
            return False, f"Failed to create branch: {str(e)}"
        finally:
            if temp_dir and Path(temp_dir).exists():
                shutil.rmtree(temp_dir, ignore_errors=True)
    
    def push_to_repository(self, project_path, repo_url, branch_name, commit_message=None):
        """Initialize git, commit, and push to repository."""
        try:
            project_path = Path(project_path)
            auth_url = self._get_authenticated_url(repo_url)
            message = commit_message or "Initial commit from AIDS Agent"
            
            # Initialize repo if needed
            if not (project_path / ".git").exists():
                repo = git.Repo.init(project_path)
            else:
                repo = git.Repo(project_path)
            
            # Configure git user
            with repo.config_writer() as config:
                config.set_value("user", "name", self.git_user_name)
                config.set_value("user", "email", self.git_user_email)
            
            # Add all files and commit
            repo.git.add(A=True)
            if repo.is_dirty() or repo.untracked_files:
                repo.index.commit(message)
                
                # Add/update remote
                if "origin" not in [r.name for r in repo.remotes]:
                    repo.create_remote("origin", auth_url)
                else:
                    repo.remotes.origin.set_url(auth_url)
                
                # Push
                repo.git.push("origin", f"HEAD:{branch_name}", "--set-upstream")
                return True, f"Code pushed to branch '{branch_name}'"
            else:
                return False, "No changes to commit"
        except Exception as e:
            return False, f"Push failed: {str(e)}"


class FileOperations:
    """File system operations."""
    
    @staticmethod
    def list_project_files(project_path):
        """List files in project directory."""
        try:
            project_path = Path(project_path)
            if not project_path.exists():
                return False, "Project path does not exist"
            
            tree = FileOperations._build_tree(project_path)
            return True, tree
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def _build_tree(directory, prefix="", max_depth=3, current_depth=0):
        """Build directory tree."""
        if current_depth >= max_depth:
            return ""
        
        ignore = {"__pycache__", ".git", ".venv", "venv", "node_modules"}
        lines = []
        
        try:
            items = sorted(directory.iterdir(), key=lambda x: (not x.is_dir(), x.name))
            items = [i for i in items if i.name not in ignore]
            
            for idx, item in enumerate(items):
                is_last = idx == len(items) - 1
                current = "└── " if is_last else "├── "
                next_prefix = "    " if is_last else "│   "
                
                if item.is_dir():
                    lines.append(f"{prefix}{current}{item.name}/")
                    subtree = FileOperations._build_tree(
                        item, prefix + next_prefix, max_depth, current_depth + 1
                    )
                    if subtree:
                        lines.append(subtree)
                else:
                    lines.append(f"{prefix}{current}{item.name}")
        except PermissionError:
            pass
        
        return "\n".join(lines)
