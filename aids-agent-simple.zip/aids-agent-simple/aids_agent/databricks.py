"""Databricks LLM client."""

import json
import requests


class DatabricksClient:
    """Simple client for Databricks LLM API."""
    
    def __init__(self, endpoint, token, model="databricks-claude-sonnet-4-6", max_tokens=4096):
        self.endpoint = endpoint
        self.token = token
        self.model = model
        self.max_tokens = max_tokens
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def chat(self, messages, tools=None):
        """Send chat request to Databricks."""
        payload = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "messages": messages
        }
        
        if tools:
            payload["tools"] = tools
        
        try:
            response = requests.post(
                self.endpoint,
                headers=self.headers,
                json=payload,
                timeout=120
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"Databricks API error: {str(e)}")


# Tool definitions for the agent
TOOLS = [
    {
        "name": "create_fastapi_project",
        "description": "Create a new FastAPI project using aids-cli with health endpoints, database connectivity, CI/CD configuration, and Helm charts.",
        "input_schema": {
            "type": "object",
            "properties": {
                "project_name": {
                    "type": "string",
                    "description": "Name of the FastAPI project"
                },
                "directory": {
                    "type": "string",
                    "description": "Directory where project should be created (optional)"
                }
            },
            "required": ["project_name"]
        }
    },
    {
        "name": "check_repository_exists",
        "description": "Check if an Azure DevOps repository exists and is accessible.",
        "input_schema": {
            "type": "object",
            "properties": {
                "repo_url": {
                    "type": "string",
                    "description": "Full ADO repository URL"
                }
            },
            "required": ["repo_url"]
        }
    },
    {
        "name": "check_branch_exists",
        "description": "Check if a specific branch exists in a repository.",
        "input_schema": {
            "type": "object",
            "properties": {
                "repo_url": {"type": "string"},
                "branch_name": {"type": "string"}
            },
            "required": ["repo_url", "branch_name"]
        }
    },
    {
        "name": "create_branch",
        "description": "Create a new branch in an Azure DevOps repository.",
        "input_schema": {
            "type": "object",
            "properties": {
                "repo_url": {"type": "string"},
                "branch_name": {"type": "string"},
                "source_branch": {
                    "type": "string",
                    "description": "Source branch (defaults to 'main')"
                }
            },
            "required": ["repo_url", "branch_name"]
        }
    },
    {
        "name": "push_to_repository",
        "description": "Initialize git, commit all files, and push to Azure DevOps.",
        "input_schema": {
            "type": "object",
            "properties": {
                "project_path": {"type": "string"},
                "repo_url": {"type": "string"},
                "branch_name": {"type": "string"},
                "commit_message": {
                    "type": "string",
                    "description": "Commit message (optional)"
                }
            },
            "required": ["project_path", "repo_url", "branch_name"]
        }
    },
    {
        "name": "list_project_files",
        "description": "List files in a generated project.",
        "input_schema": {
            "type": "object",
            "properties": {
                "project_path": {"type": "string"}
            },
            "required": ["project_path"]
        }
    }
]

SYSTEM_PROMPT = """You are AIDS Agent, an AI assistant that helps developers create and deploy FastAPI applications.

Your capabilities:
- Create FastAPI projects using aids-cli
- Push code to Azure DevOps repositories
- Manage git branches
- List project files

When helping users:
- Ask clarifying questions if needed
- Confirm before destructive operations
- Provide clear status updates
- Handle errors gracefully

Be concise and helpful."""
