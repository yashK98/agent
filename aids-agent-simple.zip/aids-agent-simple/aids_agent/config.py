"""Simple configuration management."""

import yaml
from pathlib import Path

CONFIG_PATH = Path.home() / ".aids-agent" / "config.yaml"


def load_config():
    """Load configuration from file."""
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(
            f"Configuration not found at {CONFIG_PATH}\n"
            "Run 'aids-agent configure' to create it."
        )
    
    with open(CONFIG_PATH, 'r') as f:
        return yaml.safe_load(f)


def save_config(config):
    """Save configuration to file."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    with open(CONFIG_PATH, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    
    # Secure the config file
    CONFIG_PATH.chmod(0o600)


def get_default_config():
    """Get default configuration template."""
    return {
        "databricks": {
            "endpoint": "",
            "token": "",
            "model": "databricks-claude-sonnet-4-6",
            "max_tokens": 4096
        },
        "ado": {
            "pat_token": "",
            "organization": "",
            "git_user_name": "AIDS Agent",
            "git_user_email": "aids-agent@company.com"
        }
    }
