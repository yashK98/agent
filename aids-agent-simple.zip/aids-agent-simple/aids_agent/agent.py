"""Main AI agent orchestrator."""

import json
from pathlib import Path
from aids_agent.databricks import DatabricksClient, TOOLS, SYSTEM_PROMPT
from aids_agent.tools import AIDSCLIWrapper, GitManager, FileOperations


class Agent:
    """AI Agent for FastAPI project automation."""
    
    def __init__(self, config):
        self.config = config
        
        # Initialize LLM client
        self.llm = DatabricksClient(
            endpoint=config["databricks"]["endpoint"],
            token=config["databricks"]["token"],
            model=config["databricks"]["model"],
            max_tokens=config["databricks"]["max_tokens"]
        )
        
        # Initialize tools
        self.aids_cli = AIDSCLIWrapper()
        self.git_manager = GitManager(
            pat_token=config["ado"]["pat_token"],
            organization=config["ado"]["organization"],
            git_user_name=config["ado"]["git_user_name"],
            git_user_email=config["ado"]["git_user_email"]
        )
        self.file_ops = FileOperations()
        
        # Conversation history
        self.conversation = []
    
    def chat(self, user_message):
        """Process user message and return response."""
        # Add user message
        self.conversation.append({"role": "user", "content": user_message})
        
        # Prepare messages with system prompt
        messages = [{"role": "user", "content": SYSTEM_PROMPT}] + self.conversation
        
        # Agent loop (max 10 iterations to prevent infinite loops)
        for _ in range(10):
            # Call LLM
            try:
                response = self.llm.chat(messages, tools=TOOLS)
            except Exception as e:
                return f"Error: {str(e)}"
            
            message = response["choices"][0]["message"]
            
            # Check for tool calls
            tool_calls = self._extract_tool_calls(message)
            
            if tool_calls:
                # Execute tools and continue loop
                for tool_call in tool_calls:
                    tool_result = self._execute_tool(tool_call)
                    
                    # Add tool call and result to messages
                    messages.append({
                        "role": "assistant",
                        "content": "",
                        "tool_calls": [tool_call]
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.get("id", ""),
                        "content": tool_result
                    })
            else:
                # No tool calls - this is the final response
                content = self._extract_content(message)
                self.conversation.append({"role": "assistant", "content": content})
                return content
        
        return "Error: Maximum iterations reached"
    
    def _extract_tool_calls(self, message):
        """Extract tool calls from message (handles both formats)."""
        # Standard format
        if "tool_calls" in message:
            return message["tool_calls"]
        
        # Claude format with content blocks
        if isinstance(message.get("content"), list):
            tool_calls = []
            for block in message["content"]:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    tool_calls.append({
                        "id": block.get("id", ""),
                        "type": "function",
                        "function": {
                            "name": block.get("name"),
                            "arguments": json.dumps(block.get("input", {}))
                        }
                    })
            return tool_calls if tool_calls else None
        
        return None
    
    def _extract_content(self, message):
        """Extract text content from message."""
        content = message.get("content", "")
        
        # Handle Claude format with text blocks
        if isinstance(content, list):
            text_parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
            return "\n".join(text_parts)
        
        return content
    
    def _execute_tool(self, tool_call):
        """Execute a tool and return result."""
        tool_name = tool_call["function"]["name"]
        tool_args = json.loads(tool_call["function"]["arguments"])
        
        # Route to appropriate handler
        handlers = {
            "create_fastapi_project": self._create_project,
            "check_repository_exists": self._check_repo,
            "check_branch_exists": self._check_branch,
            "create_branch": self._create_branch,
            "push_to_repository": self._push_to_repo,
            "list_project_files": self._list_files,
        }
        
        handler = handlers.get(tool_name)
        if not handler:
            return f"Unknown tool: {tool_name}"
        
        try:
            return handler(**tool_args)
        except Exception as e:
            return f"Error: {str(e)}"
    
    def _create_project(self, project_name, directory=None):
        """Create FastAPI project."""
        success, stdout, stderr = self.aids_cli.create_project(project_name, directory)
        
        if success:
            path = self.aids_cli.get_project_path(project_name, directory)
            return f"✓ Project '{project_name}' created at {path}\n\n{stdout}"
        else:
            return f"✗ Failed to create project\n{stderr}"
    
    def _check_repo(self, repo_url):
        """Check if repository exists."""
        exists, msg = self.git_manager.check_repository_exists(repo_url)
        return f"{'✓' if exists else '✗'} {msg}"
    
    def _check_branch(self, repo_url, branch_name):
        """Check if branch exists."""
        exists, msg = self.git_manager.check_branch_exists(repo_url, branch_name)
        return f"{'✓' if exists else '✗'} {msg}"
    
    def _create_branch(self, repo_url, branch_name, source_branch="main"):
        """Create a new branch."""
        success, msg = self.git_manager.create_branch(repo_url, branch_name, source_branch)
        return f"{'✓' if success else '✗'} {msg}"
    
    def _push_to_repo(self, project_path, repo_url, branch_name, commit_message=None):
        """Push project to repository."""
        success, msg = self.git_manager.push_to_repository(
            project_path, repo_url, branch_name, commit_message
        )
        return f"{'✓' if success else '✗'} {msg}"
    
    def _list_files(self, project_path):
        """List project files."""
        success, result = self.file_ops.list_project_files(project_path)
        if success:
            return f"Project structure:\n{result}"
        return f"✗ {result}"
    
    def reset(self):
        """Reset conversation history."""
        self.conversation = []
