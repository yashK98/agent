"""AIDS Agent - AI-powered FastAPI project automation."""

__version__ = "0.1.0"
